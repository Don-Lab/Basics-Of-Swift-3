
//BASICS OF SWIFT 3

//variables and data types
var num = 14; //integer
var pi = 3.14;  //double or float is a decimal
var name = "Don"; //string
var bool = true; //boolian (true or false)


//constants
let winner = "you"; //cannot change constant's value


//print
print(343) //print numbers
print("String") //pring strings
print(pi) //print variables
print("Hello " + name) //print variables with strings


//conditions - check to see if a condition is true.
/* comparison operators
 
 < - less than
 > - greater than
 >= - less than or equal to
 <= - greater than or equal too
 == - equal to
 === - equal in value and data type

*/

var volume = 10;
var loud = 7;
var quiet = 3;

if volume >= loud {
    print("The volume is too loud") //since this is true, it will run the code in the currly brackets
}
else if volume <= quiet {
    print("The volume is too quite, turn it up")
}
else {
    print("the volume is just righ!")
}


//functions
func funcName() {
    print("This is funtion, it runs the block of code in the currly brackets when called")
}
funcName()


func add(a: Int, b: Int) { //when using parameters, you must tell the data type
    print(a + b)
}
add(a:5, b: 7)

func greet(n: String) {
    print("Hello " + n)
}
greet(n: "Don")


//for loop
for loopValue in 1...10 {
    print("\(loopValue)") //loopValue is the current value of the loop (changes each cycle)
}


//while loop
var bookshelfSpace = 20;
var currentNumOfBooks = 3;
while currentNumOfBooks <= bookshelfSpace {
    currentNumOfBooks = currentNumOfBooks + 1;
    if currentNumOfBooks == bookshelfSpace {
        print("Bookshelf is full!")
    }
}


//arrays
var companies = ["Apple", "Nike", "McDonald's"];
var number = [15, 151, 36, 43, 43, 35, 345];

companies[0]; //this displays the first item in the companies array because arrays start counting at zero


//array loop (looping through an array
for business in companies {
    print("\(business)")
}








